const express = require("express");
const webpush = require("web-push");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const CONTACT = process.env.VAPID_CONTACT || "mailto:admin@example.com";
const DATA_DIR = process.env.DATA_DIR || __dirname;
const SUBS_FILE = path.join(DATA_DIR, "subscriptions.json");
const TARGET_DATE = new Date("2026-10-25T00:00:00+05:30");

if (!PUBLIC_KEY || !PRIVATE_KEY) {
  console.error("Missing VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY. See README.txt.");
  process.exit(1);
}
webpush.setVapidDetails(CONTACT, PUBLIC_KEY, PRIVATE_KEY);

function readSubs() {
  try { return JSON.parse(fs.readFileSync(SUBS_FILE, "utf8")); }
  catch { return []; }
}
function writeSubs(subs) {
  fs.mkdirSync(path.dirname(SUBS_FILE), { recursive: true });
  fs.writeFileSync(SUBS_FILE, JSON.stringify(subs, null, 2));
}
function daysLeft() {
  const now = new Date();
  const todayLocal = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  const targetLocal = new Date(TARGET_DATE.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  todayLocal.setHours(0, 0, 0, 0);
  targetLocal.setHours(0, 0, 0, 0);
  return Math.max(0, Math.ceil((targetLocal - todayLocal) / 86400000));
}
function messageForToday() {
  return `${daysLeft()} days left ❤️`;
}

app.get("/api/public-key", (_req, res) => res.json({ publicKey: PUBLIC_KEY }));

app.post("/api/subscribe", (req, res) => {
  const subscription = req.body;
  if (!subscription || !subscription.endpoint || !subscription.keys) {
    return res.status(400).json({ error: "Invalid push subscription" });
  }
  const subs = readSubs();
  if (!subs.some(s => s.endpoint === subscription.endpoint)) subs.push(subscription);
  writeSubs(subs);
  res.json({ ok: true, message: "Notifications enabled on this device." });
});

app.post("/api/test", async (_req, res) => {
  const subs = readSubs();
  const payload = JSON.stringify({ title: "Pari Countdown", body: messageForToday(), url: "/" });
  let sent = 0;
  const expired = new Set();
  await Promise.all(subs.map(async sub => {
    try { await webpush.sendNotification(sub, payload); sent++; }
    catch (e) { if (e.statusCode === 404 || e.statusCode === 410) expired.add(sub.endpoint); }
  }));
  if (expired.size) writeSubs(subs.filter(s => !expired.has(s.endpoint)));
  res.json({ ok: true, sent, message: messageForToday() });
});

async function sendDaily() {
  const subs = readSubs();
  if (!subs.length) {
    console.log("No subscribed devices; daily notification skipped.");
    return;
  }
  const payload = JSON.stringify({ title: "Pari Countdown", body: messageForToday(), url: "/" });
  const expired = new Set();
  await Promise.all(subs.map(async sub => {
    try { await webpush.sendNotification(sub, payload); }
    catch (e) {
      console.error("Push failed:", e.statusCode || e.message);
      if (e.statusCode === 404 || e.statusCode === 410) expired.add(sub.endpoint);
    }
  }));
  if (expired.size) writeSubs(subs.filter(s => !expired.has(s.endpoint)));
  console.log("Daily countdown push attempted:", messageForToday());
}

// Daily at 8:00 AM India time. Uses a simple minute check so no extra scheduler dependency is needed.
let lastSentDate = "";
setInterval(() => {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(now).reduce((o, p) => (o[p.type] = p.value, o), {});
  const dateKey = `${parts.year}-${parts.month}-${parts.day}`;
  if (parts.hour === "08" && parts.minute === "00" && lastSentDate !== dateKey) {
    lastSentDate = dateKey;
    sendDaily().catch(console.error);
  }
}, 15000);

app.listen(PORT, () => console.log(`Pari Countdown running on port ${PORT}`));
