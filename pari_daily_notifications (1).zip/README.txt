PARI DAILY COUNTDOWN — Android Web Push project

This project can send a daily phone notification that contains only:
"N days left ❤️"
Target date: 25 October 2026
Scheduled time: 8:00 AM Asia/Kolkata

IMPORTANT LIMITATIONS
- This is a source project; it is not yet a live website. You must deploy it to an HTTPS host.
- Pari must open the deployed website on her Android phone in Chrome and tap "Enable Notifications", then allow the browser prompt.
- The server must remain running at 8:00 AM daily. If the host sleeps/restarts, notifications may be missed. For reliable production use, use a host with an always-on process and persistent storage.
- The project stores push subscriptions in subscriptions.json. Configure DATA_DIR to a persistent directory on your host.
- Browser notifications are not WhatsApp messages; they appear as phone notifications from the website.
- Use this only with Pari's knowledge/permission.

DEPLOYMENT OVERVIEW
1. Upload this folder to a Node.js host that supports HTTPS and an always-on web service (for example, Render/Railway or your own server).
2. In the project directory, run: npm install
3. Generate keys: npm run generate-keys
4. Add these environment variables in the host dashboard:
   VAPID_PUBLIC_KEY = value printed by generate-keys
   VAPID_PRIVATE_KEY = value printed by generate-keys
   VAPID_CONTACT = mailto:your-real-email@example.com
   DATA_DIR = a persistent writable directory, if the host offers one
5. Deploy/start with: npm start
6. Open the deployed HTTPS website on Pari's Android phone using Chrome.
7. Tap "Enable Notifications" and choose Allow.
8. Tap "Send a test notification" to verify.
9. Keep the server online for the daily 8 AM push.

LOCAL TEST
Requires Node.js 18+.
  npm install
  npm run generate-keys
Set VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY in your shell environment, then:
  npm start

NOTE
The countdown is fixed to 25 October 2026. The server uses Asia/Kolkata time. It sends the daily notification at 8:00 AM, including "0 days left ❤️" on 25 October. It stops counting below zero after that date.
